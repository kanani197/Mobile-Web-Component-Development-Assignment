"""Audit log model for compliance."""
from datetime import datetime
from extensions import db

class AuditLog(db.Model):
    """Audit log for tracking all system actions."""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    action = db.Column(db.String(255), nullable=False, index=True)
    resource_type = db.Column(db.String(100))  # user, asset, workspace, etc.
    resource_id = db.Column(db.Integer)
    changes = db.Column(db.JSON)  # Details of what changed
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    ip_address = db.Column(db.String(45))  # IPv4 or IPv6
    
    def __repr__(self):
        return f'<AuditLog {self.action} by user {self.user_id}>'
