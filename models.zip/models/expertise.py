"""Expertise models for consultant profiles."""
from datetime import datetime
from extensions import db

user_expertise = db.Table(
    'user_expertise',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('expertise_id', db.Integer, db.ForeignKey('expertise.id'), primary_key=True)
)

class Expertise(db.Model):
    """Expertise area model."""
    __tablename__ = 'expertise'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False, index=True)
    description = db.Column(db.Text)
    
    def __repr__(self):
        return f'<Expertise {self.name}>'

class UserExpertise(db.Model):
    """User expertise association."""
    __tablename__ = 'user_expertise_items'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    expertise_id = db.Column(db.Integer, db.ForeignKey('expertise.id'), nullable=False)
    proficiency_level = db.Column(db.String(20), default='intermediate')  # beginner, intermediate, expert
    years_of_experience = db.Column(db.Integer, default=0)
    added_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    expertise = db.relationship('Expertise', backref='users')
    
    __table_args__ = (db.UniqueConstraint('user_id', 'expertise_id', name='unique_user_expertise'),)
    
    def __repr__(self):
        return f'<UserExpertise {self.user_id} - {self.expertise_id}>'
