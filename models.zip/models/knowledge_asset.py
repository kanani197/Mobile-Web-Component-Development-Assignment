"""Knowledge Asset model."""
from datetime import datetime
from enum import Enum
from extensions import db

class AssetStatus(Enum):
    """Asset workflow statuses."""
    DRAFT = 'draft'
    PENDING_VALIDATION = 'pending_validation'
    PENDING_GOVERNANCE = 'pending_governance'
    PUBLISHED = 'published'
    REJECTED = 'rejected'
    ARCHIVED = 'archived'

class KnowledgeAsset(db.Model):
    """Knowledge Asset model."""
    __tablename__ = 'knowledge_assets'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False, index=True)
    description = db.Column(db.Text)
    content = db.Column(db.Text)  # Extracted text from file
    file_path = db.Column(db.String(500))
    file_type = db.Column(db.String(20))
    file_size = db.Column(db.Integer)
    
    # Status and workflow
    status = db.Column(db.String(20), 
                      default=AssetStatus.DRAFT.value,
                      nullable=False,
                      index=True)
    
    # Relationships
    uploader_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    validator_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    governance_approver_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    validator = db.relationship('User', foreign_keys=[validator_id], backref='validated_assets')
    governance_approver = db.relationship('User', foreign_keys=[governance_approver_id],
                                         backref='governance_approved_assets')
    
    tags = db.relationship('Tag', secondary='asset_tags', lazy='dynamic',
                          backref=db.backref('assets', lazy='dynamic'))
    
    # Metadata
    view_count = db.Column(db.Integer, default=0)
    download_count = db.Column(db.Integer, default=0)
    rating = db.Column(db.Float, default=0.0)  # Average rating
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    published_at = db.Column(db.DateTime)
    
    # Validation feedback
    validation_comments = db.Column(db.Text)
    governance_comments = db.Column(db.Text)
    
    def is_published(self):
        """Check if asset is published."""
        return self.status == AssetStatus.PUBLISHED.value
    
    def is_pending_validation(self):
        """Check if asset is pending validation."""
        return self.status == AssetStatus.PENDING_VALIDATION.value
    
    def is_pending_governance(self):
        """Check if asset is pending governance."""
        return self.status == AssetStatus.PENDING_GOVERNANCE.value
    
    def increment_view_count(self):
        """Increment view count."""
        self.view_count += 1
        db.session.commit()
    
    def increment_download_count(self):
        """Increment download count."""
        self.download_count += 1
        db.session.commit()
    
    def __repr__(self):
        return f'<KnowledgeAsset {self.title}>'
