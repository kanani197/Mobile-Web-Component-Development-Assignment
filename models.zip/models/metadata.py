"""Metadata models - Tags."""
from extensions import db

asset_tags = db.Table(
    'asset_tags',
    db.Column('asset_id', db.Integer, db.ForeignKey('knowledge_assets.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tags.id'), primary_key=True)
)

class Tag(db.Model):
    """Tag model."""
    __tablename__ = 'tags'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False, index=True)
    frequency = db.Column(db.Integer, default=0)  # How many times used
    
    def __repr__(self):
        return f'<Tag {self.name}>'

# Alias for ORM relationship
class AssetTag:
    """AssetTag association - use asset_tags table directly."""
    pass
