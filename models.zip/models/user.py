"""User model."""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db, login_manager

class User(UserMixin, db.Model):
    """User model with roles."""
    __tablename__ = 'users'
    
    # Roles
    ROLE_CONSULTANT = 'consultant'
    ROLE_CHAMPION = 'champion'
    ROLE_ADMIN = 'admin'
    ROLE_GOVERNANCE = 'governance'
    
    VALID_ROLES = [ROLE_CONSULTANT, ROLE_CHAMPION, ROLE_ADMIN, ROLE_GOVERNANCE]
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(120))
    last_name = db.Column(db.String(120))
    role = db.Column(db.String(20), default=ROLE_CONSULTANT, nullable=False)
    department = db.Column(db.String(120))
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    assets = db.relationship('KnowledgeAsset', backref='uploader', lazy='dynamic',
                            foreign_keys='KnowledgeAsset.uploader_id')
    expertise_items = db.relationship('UserExpertise', backref='user', lazy='dynamic',
                                     cascade='all, delete-orphan')
    workspace_members = db.relationship('WorkspaceMember', backref='user', lazy='dynamic',
                                       cascade='all, delete-orphan')
    audit_logs = db.relationship('AuditLog', backref='user', lazy='dynamic',
                                foreign_keys='AuditLog.user_id')
    
    def set_password(self, password):
        """Hash and set password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Verify password hash."""
        return check_password_hash(self.password_hash, password)
    
    def has_role(self, role):
        """Check if user has specific role."""
        return self.role == role
    
    def is_champion_or_admin(self):
        """Check if user is champion or admin."""
        return self.role in [self.ROLE_CHAMPION, self.ROLE_ADMIN]
    
    def is_governance(self):
        """Check if user is in governance."""
        return self.role == self.ROLE_GOVERNANCE
    
    def is_admin(self):
        """Check if user is admin."""
        return self.role == self.ROLE_ADMIN
    
    @property
    def full_name(self):
        """Get user's full name."""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.username
    
    def __repr__(self):
        return f'<User {self.username}>'

@login_manager.user_loader
def load_user(user_id):
    """Load user for Flask-Login."""
    return User.query.get(int(user_id))
