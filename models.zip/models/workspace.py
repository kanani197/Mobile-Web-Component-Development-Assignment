"""Workspace model for collaboration."""
from datetime import datetime
from extensions import db

class Workspace(db.Model):
    """Workspace model for team collaboration."""
    __tablename__ = 'workspaces'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    owner = db.relationship('User', backref='owned_workspaces',
                           foreign_keys=[owner_id])
    members = db.relationship('WorkspaceMember', backref='workspace', lazy='dynamic',
                             cascade='all, delete-orphan')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Workspace {self.name}>'

class WorkspaceMember(db.Model):
    """Workspace member association."""
    __tablename__ = 'workspace_members'
    
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey('workspaces.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    role = db.Column(db.String(20), default='member')  # owner, editor, viewer
    
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    __table_args__ = (db.UniqueConstraint('workspace_id', 'user_id', name='unique_workspace_user'),)
    
    def __repr__(self):
        return f'<WorkspaceMember {self.user_id} in {self.workspace_id}>'
