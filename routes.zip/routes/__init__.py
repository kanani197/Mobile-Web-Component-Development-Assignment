"""Routes package."""
from routes import auth, consultant, champion, governance, admin, search, main

__all__ = [
    'auth',
    'consultant',
    'champion',
    'governance',
    'admin',
    'search',
    'main'
]
