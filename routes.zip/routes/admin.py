"""Admin blueprint."""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from extensions import db
from models import User, KnowledgeAsset, AuditLog
from services import AuditService
from utils.decorators import admin_required

bp = Blueprint('admin', __name__, url_prefix='/admin')
audit_service = AuditService()

@bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    """Admin dashboard."""
    total_users = User.query.count()
    total_assets = KnowledgeAsset.query.count()
    total_published = KnowledgeAsset.query.filter_by(status='published').count()
    
    stats = {
        'total_users': total_users,
        'total_assets': total_assets,
        'published_assets': total_published,
        'pending_validation': KnowledgeAsset.query.filter_by(status='pending_validation').count(),
        'pending_governance': KnowledgeAsset.query.filter_by(status='pending_governance').count(),
    }
    
    recent_logs = AuditLog.query.order_by(
        AuditLog.timestamp.desc()
    ).limit(10).all()
    
    return render_template('admin/dashboard.html',
                         stats=stats,
                         recent_logs=recent_logs)

@bp.route('/users')
@login_required
@admin_required
def users():
    """Manage users."""
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    users_page = User.query.paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin/users.html', users=users_page)

@bp.route('/user/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(user_id):
    """Edit user."""
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('admin.users'))
    
    if request.method == 'POST':
        user.first_name = request.form.get('first_name', '').strip()
        user.last_name = request.form.get('last_name', '').strip()
        user.email = request.form.get('email', '').strip()
        user.role = request.form.get('role', user.role)
        user.department = request.form.get('department', '').strip()
        
        is_active = request.form.get('is_active', False) == 'on'
        if user.is_active != is_active:
            user.is_active = is_active
        
        db.session.commit()
        
        audit_service.log_action(
            current_user.id,
            'user_updated',
            'user',
            user_id,
            {'role': user.role, 'is_active': user.is_active}
        )
        
        flash('User updated successfully!', 'success')
        return redirect(url_for('admin.users'))
    
    return render_template('admin/edit_user.html',
                         user=user,
                         roles=User.VALID_ROLES)

@bp.route('/user/<int:user_id>/disable', methods=['POST'])
@login_required
@admin_required
def disable_user(user_id):
    """Disable user account."""
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('admin.users'))
    
    if user.id == current_user.id:
        flash('Cannot disable your own account', 'danger')
        return redirect(url_for('admin.users'))
    
    user.is_active = False
    db.session.commit()
    
    audit_service.log_action(
        current_user.id,
        'user_disabled',
        'user',
        user_id,
        {}
    )
    
    flash(f'User {user.username} disabled', 'success')
    return redirect(url_for('admin.users'))


