"""Authentication blueprint."""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db
from models import User
from services import AuditService

bp = Blueprint('auth', __name__, url_prefix='/auth')
audit_service = AuditService()

@bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration."""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        password_confirm = request.form.get('password_confirm', '').strip()
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        role = request.form.get('role', 'consultant')
        department = request.form.get('department', '').strip()
        
        # Validation
        if not username or len(username) < 3:
            flash('Username must be at least 3 characters', 'danger')
            return render_template('auth/register.html')
        
        if not email or '@' not in email:
            flash('Please enter a valid email', 'danger')
            return render_template('auth/register.html')
        
        if not password or len(password) < 6:
            flash('Password must be at least 6 characters', 'danger')
            return render_template('auth/register.html')
        
        if password != password_confirm:
            flash('Passwords do not match', 'danger')
            return render_template('auth/register.html')
        
        if role not in User.VALID_ROLES:
            flash('Invalid role', 'danger')
            return render_template('auth/register.html')
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('auth/register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return render_template('auth/register.html')
        
        # Create user
        user = User(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name,
            role=role,
            department=department
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Log audit
        audit_service.log_action(
            user.id,
            'user_registered',
            'user',
            user.id,
            {'username': username, 'email': email, 'role': role}
        )
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html', roles=User.VALID_ROLES)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login."""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        remember = request.form.get('remember', False)
        
        if not username or not password:
            flash('Please enter username and password', 'danger')
            return render_template('auth/login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not user.check_password(password):
            flash('Invalid username or password', 'danger')
            audit_service.log_action(
                0,
                'login_failed',
                'user',
                0,
                {'username': username}
            )
            return render_template('auth/login.html')
        
        if not user.is_active:
            flash('Your account is disabled', 'danger')
            return render_template('auth/login.html')
        
        login_user(user, remember=remember)
        
        # Log audit
        audit_service.log_action(
            user.id,
            'user_login',
            'user',
            user.id,
            {}
        )
        
        next_page = request.args.get('next')
        return redirect(next_page) if next_page else redirect(url_for('main.dashboard'))
    
    return render_template('auth/login.html')

@bp.route('/logout')
@login_required
def logout():
    """User logout."""
    audit_service.log_action(
        current_user.id,
        'user_logout',
        'user',
        current_user.id,
        {}
    )
    
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('main.index'))
