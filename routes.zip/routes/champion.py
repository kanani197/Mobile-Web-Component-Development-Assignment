"""Knowledge Champion blueprint."""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import KnowledgeAsset, AssetStatus
from services import ValidationService, AuditService
from utils.decorators import champion_or_admin_required

bp = Blueprint('champion', __name__, url_prefix='/champion')
validation_service = ValidationService()
audit_service = AuditService()

@bp.route('/dashboard')
@login_required
@champion_or_admin_required
def dashboard():
    """Champion dashboard."""
    pending = KnowledgeAsset.query.filter_by(
        status=AssetStatus.PENDING_VALIDATION.value
    ).all()
    
    validated = KnowledgeAsset.query.filter_by(validator_id=current_user.id).all()
    
    return render_template('champion/dashboard.html',
                         pending_assets=pending,
                         validated_assets=validated)

@bp.route('/validate/<int:asset_id>', methods=['GET', 'POST'])
@login_required
@champion_or_admin_required
def validate_asset(asset_id):
    """Validate asset."""
    asset = KnowledgeAsset.query.get(asset_id)
    
    if not asset:
        flash('Asset not found', 'danger')
        return redirect(url_for('champion.dashboard'))
    
    if asset.status != AssetStatus.PENDING_VALIDATION.value:
        flash('Asset is not pending validation', 'danger')
        return redirect(url_for('champion.dashboard'))
    
    if request.method == 'POST':
        action = request.form.get('action')
        comments = request.form.get('comments', '').strip()
        send_to_governance = request.form.get('send_to_governance', False) == 'on'
        
        if action == 'approve':
            success, message = validation_service.approve_asset(
                asset_id,
                comments,
                send_to_governance
            )
        elif action == 'reject':
            success, message = validation_service.reject_asset(
                asset_id,
                comments
            )
        else:
            flash('Invalid action', 'danger')
            return render_template('champion/validate_asset.html', asset=asset)
        
        flash(message, 'success' if success else 'danger')
        return redirect(url_for('champion.dashboard'))
    
    return render_template('champion/validate_asset.html', asset=asset)

@bp.route('/pending')
@login_required
@champion_or_admin_required
def pending_assets():
    """View all pending assets."""
    pending = KnowledgeAsset.query.filter_by(
        status=AssetStatus.PENDING_VALIDATION.value
    ).all()
    
    return render_template('champion/pending_validation.html',
                         assets=pending)
