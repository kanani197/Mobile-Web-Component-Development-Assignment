"""Consultant blueprint."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from flask_login import login_required, current_user
from extensions import db
from models import KnowledgeAsset, Workspace, WorkspaceMember
from services import UploadService, AuditService
from utils.decorators import role_required
import os

bp = Blueprint('consultant', __name__, url_prefix='/consultant')
upload_service = UploadService()
audit_service = AuditService()

@bp.route('/dashboard')
@login_required
@role_required('consultant')
def dashboard():
    """Consultant dashboard."""
    assets = KnowledgeAsset.query.filter_by(uploader_id=current_user.id).all()
    workspaces = Workspace.query.filter_by(owner_id=current_user.id).all()
    return render_template('consultant/dashboard.html',
                         assets=assets,
                         workspaces=workspaces)

@bp.route('/upload', methods=['GET', 'POST'])
@login_required
@role_required('consultant')
def upload():
    """Upload knowledge asset."""
    if request.method == 'POST':
        file = request.files.get('file')
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        expertise = request.form.getlist('expertise')
        
        # Validation
        if not title:
            flash('Please enter a title', 'danger')
            return render_template('consultant/upload.html')
        
        if not file:
            flash('Please select a file', 'danger')
            return render_template('consultant/upload.html')
        
        # Upload
        asset, error = upload_service.upload_asset(file, title, description, expertise)
        
        if error:
            flash(f'Upload failed: {error}', 'danger')
            return render_template('consultant/upload.html')
        
        flash('Asset uploaded successfully! It is pending champion validation.', 'success')
        return redirect(url_for('consultant.view_asset', asset_id=asset.id))
    
    return render_template('consultant/upload.html')

@bp.route('/asset/<int:asset_id>')
@login_required
def view_asset(asset_id):
    """View asset details."""
    asset = KnowledgeAsset.query.get(asset_id)
    
    if not asset:
        flash('Asset not found', 'danger')
        return redirect(url_for('consultant.dashboard'))
    
    # Check permission
    if asset.uploader_id != current_user.id and not current_user.is_admin():
        flash('You do not have permission to view this asset', 'danger')
        return redirect(url_for('main.index'))
    
    return render_template('consultant/asset_detail.html', asset=asset)

@bp.route('/asset/<int:asset_id>/delete', methods=['POST'])
@login_required
def delete_asset(asset_id):
    """Delete asset."""
    success, message = upload_service.delete_asset(asset_id)
    
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('consultant.dashboard'))

@bp.route('/workspaces')
@login_required
@role_required('consultant')
def workspaces():
    """Manage workspaces."""
    owned = Workspace.query.filter_by(owner_id=current_user.id).all()
    members = db.session.query(Workspace).join(WorkspaceMember).filter(
        WorkspaceMember.user_id == current_user.id
    ).all()
    
    return render_template('consultant/workspaces.html',
                         owned_workspaces=owned,
                         member_workspaces=members)

@bp.route('/workspace/create', methods=['GET', 'POST'])
@login_required
@role_required('consultant')
def create_workspace():
    """Create workspace."""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        
        if not name:
            flash('Please enter a workspace name', 'danger')
            return render_template('consultant/create_workspace.html')
        
        workspace = Workspace(
            name=name,
            description=description,
            owner_id=current_user.id
        )
        db.session.add(workspace)
        db.session.commit()
        
        audit_service.log_action(
            current_user.id,
            'workspace_created',
            'workspace',
            workspace.id,
            {'name': name}
        )
        
        flash('Workspace created successfully!', 'success')
        return redirect(url_for('consultant.workspaces'))
    
    return render_template('consultant/create_workspace.html')

@bp.route('/workspace/<int:workspace_id>/add_member', methods=['POST'])
@login_required
@role_required('consultant')
def add_workspace_member(workspace_id):
    """Add member to workspace."""
    workspace = Workspace.query.get(workspace_id)
    
    if not workspace or workspace.owner_id != current_user.id:
        flash('Workspace not found or permission denied', 'danger')
        return redirect(url_for('consultant.workspaces'))
    
    username = request.form.get('username', '').strip()
    user = User.query.filter_by(username=username).first()
    
    if not user:
        flash('User not found', 'danger')
    else:
        # Check if already member
        existing = WorkspaceMember.query.filter_by(
            workspace_id=workspace_id,
            user_id=user.id
        ).first()
        
        if existing:
            flash('User is already a member', 'danger')
        else:
            member = WorkspaceMember(
                workspace_id=workspace_id,
                user_id=user.id,
                role='member'
            )
            db.session.add(member)
            db.session.commit()
            
            audit_service.log_action(
                current_user.id,
                'workspace_member_added',
                'workspace',
                workspace_id,
                {'user_id': user.id}
            )
            
            flash(f'{user.full_name} added to workspace', 'success')
    
    return redirect(url_for('consultant.workspaces'))

@bp.route('/asset/<int:asset_id>/download')
@login_required
def download_asset(asset_id):
    """Download asset file."""
    asset = KnowledgeAsset.query.get(asset_id)
    
    if not asset:
        flash('Asset not found', 'danger')
        return redirect(url_for('main.index'))
    
    if asset.status != 'published' and asset.uploader_id != current_user.id and not current_user.is_admin():
        flash('You do not have permission to download this asset', 'danger')
        return redirect(url_for('main.index'))
    
    try:
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], asset.file_path)
        if not os.path.exists(filepath):
            flash('File not found', 'danger')
            return redirect(url_for('main.index'))
        
        # Increment download count
        asset.increment_download_count()
        
        # Log audit
        audit_service.log_action(
            current_user.id,
            'asset_downloaded',
            'asset',
            asset_id,
            {}
        )
        
        return send_file(filepath, as_attachment=True)
    except Exception as e:
        current_app.logger.error(f"Download error: {e}")
        flash('Download failed', 'danger')
        return redirect(url_for('main.index'))

# Import at end to avoid circular imports
from flask_login import current_user
from models import User
from flask import current_app
