"""Governance blueprint."""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import KnowledgeAsset, AssetStatus, AuditLog
from services import ValidationService, AuditService
from utils.decorators import governance_required

bp = Blueprint('governance', __name__, url_prefix='/governance')
validation_service = ValidationService()
audit_service = AuditService()

@bp.route('/dashboard')
@login_required
@governance_required
def dashboard():
    """Governance dashboard."""
    pending = KnowledgeAsset.query.filter_by(
        status=AssetStatus.PENDING_GOVERNANCE.value
    ).all()
    
    approved = KnowledgeAsset.query.filter_by(
        governance_approver_id=current_user.id
    ).all()
    
    return render_template('governance/dashboard.html',
                         pending_assets=pending,
                         approved_assets=approved)

@bp.route('/review/<int:asset_id>', methods=['GET', 'POST'])
@login_required
@governance_required
def review_asset(asset_id):
    """Review asset for governance compliance."""
    asset = KnowledgeAsset.query.get(asset_id)
    
    if not asset:
        flash('Asset not found', 'danger')
        return redirect(url_for('governance.dashboard'))
    
    if asset.status != AssetStatus.PENDING_GOVERNANCE.value:
        flash('Asset is not pending governance review', 'danger')
        return redirect(url_for('governance.dashboard'))
    
    if request.method == 'POST':
        action = request.form.get('action')
        comments = request.form.get('comments', '').strip()
        
        if action == 'approve':
            success, message = validation_service.governance_approve(
                asset_id,
                comments
            )
        elif action == 'reject':
            success, message = validation_service.governance_reject(
                asset_id,
                comments
            )
        else:
            flash('Invalid action', 'danger')
            return render_template('governance/compliance_review.html', asset=asset)
        
        flash(message, 'success' if success else 'danger')
        return redirect(url_for('governance.dashboard'))
    
    return render_template('governance/compliance_review.html', asset=asset)

@bp.route('/pending')
@login_required
@governance_required
def pending_reviews():
    """View all pending governance reviews."""
    pending = KnowledgeAsset.query.filter_by(
        status=AssetStatus.PENDING_GOVERNANCE.value
    ).all()
    
    return render_template('governance/pending_reviews.html',
                         assets=pending)

@bp.route('/audit-logs')
@login_required
@governance_required
def audit_logs():
    """View audit logs."""
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    logs = AuditLog.query.order_by(
        AuditLog.timestamp.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('governance/audit_logs.html', logs=logs)

@bp.route('/audit-logs/filter', methods=['GET', 'POST'])
@login_required
@governance_required
def filter_audit_logs():
    """Filter audit logs."""
    filters = {}
    
    if request.method == 'POST':
        action = request.form.get('action')
        user_id = request.form.get('user_id')
        resource_type = request.form.get('resource_type')
        
        if action:
            filters['action'] = action
        if user_id:
            filters['user_id'] = user_id
        if resource_type:
            filters['resource_type'] = resource_type
    
    logs = audit_service.get_logs(filters=filters, limit=100)
    
    return render_template('governance/audit_logs.html', logs=logs)
