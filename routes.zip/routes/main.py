"""Main blueprint - public routes."""
from flask import Blueprint, render_template, request
from flask_login import current_user, login_required
from extensions import db
from models import KnowledgeAsset, AssetStatus, User
from services import SearchService

bp = Blueprint('main', __name__)
search_service = SearchService()

@bp.route('/')
def index():
    """Landing page."""
    if current_user.is_authenticated:
        # Show dashboard based on role
        if current_user.role == 'consultant':
            return render_template('consultant/dashboard.html', user=current_user)
        elif current_user.role in ['champion', 'admin']:
            pending = KnowledgeAsset.query.filter_by(
                status=AssetStatus.PENDING_VALIDATION.value
            ).count()
            return render_template('champion/dashboard.html', pending_count=pending)
        elif current_user.role == 'governance':
            pending = KnowledgeAsset.query.filter_by(
                status=AssetStatus.PENDING_GOVERNANCE.value
            ).count()
            return render_template('governance/dashboard.html', pending_count=pending)
    
    # Show landing page for guests
    recent_assets = search_service.get_recent_assets(limit=5)
    trending_assets = search_service.get_trending_assets(limit=5)
    total_assets = KnowledgeAsset.query.filter_by(
        status=AssetStatus.PUBLISHED.value
    ).count()
    total_users = User.query.count()
    
    return render_template('index.html',
                         recent_assets=recent_assets,
                         trending_assets=trending_assets,
                         total_assets=total_assets,
                         total_users=total_users)

@bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard."""
    if current_user.role == 'consultant':
        assets = KnowledgeAsset.query.filter_by(uploader_id=current_user.id).all()
        return render_template('consultant/dashboard.html', assets=assets)
    elif current_user.role in ['champion', 'admin']:
        pending = KnowledgeAsset.query.filter_by(
            status=AssetStatus.PENDING_VALIDATION.value
        ).all()
        return render_template('champion/dashboard.html', pending_assets=pending)
    elif current_user.role == 'governance':
        pending = KnowledgeAsset.query.filter_by(
            status=AssetStatus.PENDING_GOVERNANCE.value
        ).all()
        return render_template('governance/dashboard.html', pending_assets=pending)
    else:
        return render_template('index.html')
