"""Search blueprint."""
from flask import Blueprint, render_template, request
from flask_login import login_required
from models import Tag, KnowledgeAsset, AssetStatus
from services import SearchService, AuditService

bp = Blueprint('search', __name__, url_prefix='/search')
search_service = SearchService()
audit_service = AuditService()

@bp.route('/')
def search():
    """Search published assets."""
    query = request.args.get('q', '').strip()
    page = request.args.get('page', 1, type=int)
    tags = request.args.getlist('tags')
    file_type = request.args.get('file_type', '')
    
    filters = {}
    if tags:
        tag_objects = Tag.query.filter(Tag.name.in_(tags)).all()
        if tag_objects:
            filters['tags'] = tag_objects
    
    if file_type:
        filters['file_type'] = file_type
    
    # Search
    results = search_service.search(query, page=page, filters=filters)
    
    # Get all tags for filter
    all_tags = Tag.query.all()
    
    # Log search in audit
    if query:
        audit_service.log_action(
            0 if not request.args.get('logged_in') else -1,
            'asset_searched',
            'search',
            None,
            {'query': query}
        )
    
    return render_template('search/search.html',
                         results=results,
                         query=query,
                         all_tags=all_tags,
                         selected_tags=tags,
                         selected_file_type=file_type)



@bp.route('/asset/<int:asset_id>')
def view_asset(asset_id):
    """View asset details."""
    asset = KnowledgeAsset.query.get(asset_id)
    
    if not asset or asset.status != AssetStatus.PUBLISHED.value:
        return render_template('errors/404.html'), 404
    
    # Increment view count
    asset.increment_view_count()
    
    # Get related assets
    related = search_service.get_related_assets(asset_id, limit=5)
    
    # Log audit
    audit_service.log_action(
        0,
        'asset_viewed',
        'asset',
        asset_id,
        {}
    )
    
    return render_template('search/asset_detail.html',
                         asset=asset,
                         related_assets=related)
