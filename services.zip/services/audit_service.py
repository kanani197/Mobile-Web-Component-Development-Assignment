"""Audit service for compliance logging."""
from datetime import datetime
from flask import request
from flask_login import current_user
from extensions import db
from models import AuditLog

class AuditService:
    """Service for audit logging."""
    
    @staticmethod
    def log_action(user_id, action, resource_type, resource_id, changes=None):
        """
        Log an action for audit trail.
        
        Args:
            user_id: ID of user performing action
            action: Action name (e.g., 'asset_uploaded')
            resource_type: Type of resource (e.g., 'asset')
            resource_id: ID of resource
            changes: Dict of changes made
        """
        # Get IP address
        ip_address = request.remote_addr if request else None
        
        log = AuditLog(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            changes=changes,
            ip_address=ip_address
        )
        
        db.session.add(log)
        db.session.commit()
    
    @staticmethod
    def get_logs(filters=None, limit=None):
        """
        Get audit logs with optional filters.
        
        Args:
            filters: Dict with filters (user_id, action, resource_type, etc.)
            limit: Maximum number of logs to return
        
        Returns:
            list: AuditLog objects
        """
        query = AuditLog.query
        
        filters = filters or {}
        
        if 'user_id' in filters:
            query = query.filter_by(user_id=filters['user_id'])
        
        if 'action' in filters:
            query = query.filter_by(action=filters['action'])
        
        if 'resource_type' in filters:
            query = query.filter_by(resource_type=filters['resource_type'])
        
        if 'resource_id' in filters:
            query = query.filter_by(resource_id=filters['resource_id'])
        
        if 'date_from' in filters:
            query = query.filter(AuditLog.timestamp >= filters['date_from'])
        
        if 'date_to' in filters:
            query = query.filter(AuditLog.timestamp <= filters['date_to'])
        
        query = query.order_by(AuditLog.timestamp.desc())
        
        if limit:
            query = query.limit(limit)
        
        return query.all()
    
    @staticmethod
    def get_user_activity(user_id, limit=50):
        """
        Get activity log for a specific user.
        
        Args:
            user_id: User ID
            limit: Maximum number of logs
        
        Returns:
            list: AuditLog objects
        """
        return AuditLog.query.filter_by(
            user_id=user_id
        ).order_by(
            AuditLog.timestamp.desc()
        ).limit(limit).all()
