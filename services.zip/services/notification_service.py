"""Notification service for alerts and messages."""
from flask import current_app, url_for
from models import User, KnowledgeAsset

class NotificationService:
    """Service for sending notifications."""
    
    @staticmethod
    def notify_champions_new_asset(asset):
        """
        Notify champions of new asset pending validation.
        
        Args:
            asset: KnowledgeAsset object
        """
        champions = User.query.filter(
            User.role.in_(['champion', 'admin'])
        ).all()
        
        # In production, send email or push notifications
        for champion in champions:
            notification_data = {
                'type': 'new_asset',
                'asset_id': asset.id,
                'asset_title': asset.title,
                'uploader': asset.uploader.full_name,
                'url': f'/champion/validate/{asset.id}'
            }
            # Store in database or send email
            current_app.logger.info(f"Notifying {champion.username} of new asset")
    
    @staticmethod
    def notify_uploader_approved(asset):
        """
        Notify uploader that asset was approved.
        
        Args:
            asset: KnowledgeAsset object
        """
        uploader = asset.uploader
        notification_data = {
            'type': 'asset_approved',
            'asset_id': asset.id,
            'asset_title': asset.title,
            'url': f'/asset/{asset.id}'
        }
        current_app.logger.info(f"Notifying {uploader.username} of approval")
    
    @staticmethod
    def notify_uploader_rejected(asset):
        """
        Notify uploader that asset was rejected.
        
        Args:
            asset: KnowledgeAsset object
        """
        uploader = asset.uploader
        notification_data = {
            'type': 'asset_rejected',
            'asset_id': asset.id,
            'asset_title': asset.title,
            'comments': asset.validation_comments,
            'url': f'/asset/{asset.id}'
        }
        current_app.logger.info(f"Notifying {uploader.username} of rejection")
    
    @staticmethod
    def notify_governance_new_review(asset):
        """
        Notify governance of asset pending review.
        
        Args:
            asset: KnowledgeAsset object
        """
        governance_users = User.query.filter_by(role='governance').all()
        
        for user in governance_users:
            notification_data = {
                'type': 'governance_review',
                'asset_id': asset.id,
                'asset_title': asset.title,
                'url': f'/governance/review/{asset.id}'
            }
            current_app.logger.info(f"Notifying {user.username} of governance review")
