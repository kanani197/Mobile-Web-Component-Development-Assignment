"""Recommendation engine for AI-powered suggestions."""
from flask import current_app
from models import Tag, User, Expertise
from extensions import db

class RecommendationEngine:
    """AI recommendation engine for tags and experts."""
    
    def __init__(self):
        """Initialize recommendation engine."""
        pass
    
    def suggest_tags(self, title, description, content='', top_n=None):
        """
        Suggest tags for a knowledge asset using keyword matching.
        
        Args:
            title: Asset title
            description: Asset description
            content: Asset content/text
            top_n: Number of top tags (uses config if None)
        
        Returns:
            list: List of suggested Tag objects
        """
        if top_n is None:
            top_n = current_app.config.get('MAX_TAGS_PER_ASSET', 5)
        
        # Combine text
        text = f"{title} {description} {content}".lower()
        
        # Get existing tags
        existing_tags = Tag.query.all()
        if not existing_tags:
            return []
        
        # Simple keyword matching - count occurrences
        tag_scores = {}
        for tag in existing_tags:
            tag_name_lower = tag.name.lower()
            # Count how many times tag appears in the text
            count = text.count(tag_name_lower)
            if count > 0:
                tag_scores[tag.id] = count
        
        # Sort by score and get top N
        if not tag_scores:
            # Return most frequent tags if no matches
            return Tag.query.order_by(Tag.frequency.desc()).limit(top_n).all()
        

    def find_experts(self, tags=None, expertise_names=None):
        """
        Find users with expertise in given areas.
        
        Args:
            tags: List of Tag objects
            expertise_names: List of expertise area names
        
        Returns:
            list: List of (User, score) tuples sorted by score
        """
        if not tags and not expertise_names:
            return []
        
        users_with_expertise = {}
        
        # Find users with relevant expertise
        if expertise_names:
            for expertise_name in expertise_names:
                user_expertise = db.session.query(User).join(
                    db.Table(
                        'user_expertise',
                        db.Column('user_id', db.Integer, db.ForeignKey('user.id')),
                        db.Column('expertise_id', db.Integer, db.ForeignKey('expertise.id'))
                    )
                ).filter(
                    Expertise.name.ilike(f"%{expertise_name}%")
                ).all()
                
                for user in user_expertise:
                    users_with_expertise[user.id] = users_with_expertise.get(user.id, 0) + 1
        
        # Get top 5 experts
        if users_with_expertise:
            top_user_ids = sorted(
                users_with_expertise.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:5]
            users = [User.query.get(uid) for uid, _ in top_user_ids]
            return [(u, users_with_expertise[u.id]) for u in users if u]
        
        return []
    
    def rank_by_relevance(self, search_text, assets):
        """
        Rank assets by relevance to search text.
        
        Args:
            search_text: Search query
            assets: List of KnowledgeAsset objects
        
        Returns:
            list: Assets sorted by relevance score
        """
        if not search_text or not assets:
            return assets
        
        search_lower = search_text.lower()
        scored_assets = []
        
        for asset in assets:
            score = 0
            asset_text = f"{asset.title} {asset.description} {asset.content}".lower()
            
            # Keyword matching score
            if search_lower in asset_text:
                score += 10  # Full phrase match
            else:
                # Count individual word matches
                for word in search_lower.split():
                    if len(word) > 2:  # Ignore short words
                        score += asset_text.count(word)
            
            scored_assets.append((asset, score))
        
        # Sort by score descending
        return [asset for asset, score in sorted(scored_assets, key=lambda x: x[1], reverse=True)]
    
    def analyze_skill_gaps(self, knowledge_domain):
        """
        Analyze skill gaps in a knowledge domain.
        
        Args:
            knowledge_domain: Domain to analyze
        
        Returns:
            dict: Analysis results
        """
        return {
            'domain': knowledge_domain,
            'gaps': [],
            'recommendations': []
        }

    
    def suggest_tags(self, title, description, content='', top_n=None):
        """
        Suggest tags for a knowledge asset using TF-IDF.
        
        Args:
            title: Asset title
            description: Asset description
            content: Asset content/text
            top_n: Number of top tags (uses config if None)
        
        Returns:
            list: List of suggested Tag objects
        """
        if top_n is None:
            top_n = current_app.config.get('MAX_TAGS_PER_ASSET', 5)
        
        # Combine text
        text = f"{title} {description} {content}"
        
        # Get existing tags
        existing_tags = Tag.query.all()
        if not existing_tags:
            return []
        
        existing_tag_names = [tag.name for tag in existing_tags]
        
        try:
            # Create TF-IDF matrix
            all_texts = existing_tag_names + [text]
            tfidf_matrix = self.vectorizer.fit_transform(all_texts)
            
            # Calculate similarity
            asset_vector = tfidf_matrix[-1]
            tag_vectors = tfidf_matrix[:-1]
            
            similarities = cosine_similarity(asset_vector, tag_vectors).flatten()
            
            # Get top matches
            top_indices = np.argsort(similarities)[-top_n:][::-1]
            threshold = current_app.config.get('SIMILARITY_THRESHOLD', 0.3)
            
            suggested_tags = []
            for idx in top_indices:
                if similarities[idx] >= threshold:
                    suggested_tags.append(existing_tags[idx])
            
            return suggested_tags
        except Exception as e:
            current_app.logger.error(f"Error suggesting tags: {e}")
            return []
    
    def find_experts(self, tags, expertise_names=None, top_n=None):
        """
        Find expert consultants based on tags and expertise.
        
        Args:
            tags: List of Tag objects
            expertise_names: List of expertise area names
            top_n: Number of top experts (uses config if None)
        
        Returns:
            list: List of expert User objects
        """
        if top_n is None:
            top_n = current_app.config.get('MAX_EXPERTS_PER_ASSET', 3)
        
        expert_scores = {}
        
        # Score by tag matching
        for tag in tags:
            for asset in tag.assets:
                uploader = asset.uploader
                if uploader.role in ['consultant', 'champion']:
                    expert_scores[uploader.id] = expert_scores.get(uploader.id, 0) + 1
        
        # Score by expertise matching
        if expertise_names:
            for expertise_name in expertise_names:
                expertise = Expertise.query.filter_by(name=expertise_name).first()
                if expertise:
                    for user_expertise in expertise.users:
                        user_id = user_expertise.user_id
                        expert_scores[user_id] = expert_scores.get(user_id, 0) + 2
        
        # Get top experts
        if not expert_scores:
            # Return random consultants if no scores
            return User.query.filter_by(role='consultant').limit(top_n).all()
        
        top_user_ids = sorted(expert_scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
        experts = [User.query.get(uid) for uid, score in top_user_ids if User.query.get(uid)]
        
        return experts
    
    def rank_by_relevance(self, search_text, assets):
        """
        Rank assets by relevance to search text.
        
        Args:
            search_text: Search query text
            assets: List of KnowledgeAsset objects
        
        Returns:
            list: Sorted assets by relevance
        """
        if not assets or not search_text:
            return assets
        
        try:
            texts = [f"{a.title} {a.description}" for a in assets]
            all_texts = texts + [search_text]
            
            tfidf_matrix = self.vectorizer.fit_transform(all_texts)
            search_vector = tfidf_matrix[-1]
            asset_vectors = tfidf_matrix[:-1]
            
            similarities = cosine_similarity(search_vector, asset_vectors).flatten()
            
            # Sort assets by similarity
            sorted_indices = np.argsort(similarities)[::-1]
            return [assets[i] for i in sorted_indices]
        except Exception as e:
            current_app.logger.error(f"Error ranking by relevance: {e}")
            return assets
    
    def analyze_skill_gaps(self, knowledge_domain):
        """
        Analyze skill gaps for a knowledge domain.
        
        Args:
            knowledge_domain: Domain/expertise area name
        
        Returns:
            dict: Skill gap analysis
        """
        expertise = Expertise.query.filter_by(name=knowledge_domain).first()
        if not expertise:
            return {}
        
        user_expertise = expertise.users
        total_users = db.session.query(User).filter_by(role='consultant').count()
        
        analysis = {
            'domain': knowledge_domain,
            'total_consultants': total_users,
            'with_expertise': len(user_expertise),
            'gap_percentage': ((total_users - len(user_expertise)) / total_users * 100) if total_users > 0 else 0,
            'proficiency_breakdown': {}
        }
        
        for level in ['beginner', 'intermediate', 'expert']:
            count = sum(1 for ue in user_expertise if ue.proficiency_level == level)
            analysis['proficiency_breakdown'][level] = count
        
        return analysis

