"""Search service for asset discovery."""
from flask import current_app
from extensions import db
from models import KnowledgeAsset, Tag, AssetStatus
from services.recommendation_engine import RecommendationEngine
from sqlalchemy import or_, and_

class SearchService:
    """Service for searching knowledge assets."""
    
    def __init__(self):
        """Initialize search service."""
        self.recommendation_engine = RecommendationEngine()
    
    def search(self, query, page=1, per_page=None, filters=None):
        """
        Search published assets by keyword.
        
        Args:
            query: Search query string
            page: Page number (1-indexed)
            per_page: Items per page (uses config if None)
            filters: Dict with optional filters (tags, file_type, uploader_id)
        
        Returns:
            Pagination: Paginated results
        """
        if per_page is None:
            per_page = current_app.config.get('ITEMS_PER_PAGE', 10)
        
        filters = filters or {}
        
        # Base query - only published assets
        search_query = KnowledgeAsset.query.filter_by(
            status=AssetStatus.PUBLISHED.value
        )
        
        # Keyword search
        if query:
            search_term = f"%{query}%"
            search_query = search_query.filter(
                or_(
                    KnowledgeAsset.title.ilike(search_term),
                    KnowledgeAsset.description.ilike(search_term),
                    KnowledgeAsset.content.ilike(search_term)
                )
            )
        
        # Filter by file type
        if 'file_type' in filters:
            search_query = search_query.filter_by(file_type=filters['file_type'])
        
        # Filter by uploader
        if 'uploader_id' in filters:
            search_query = search_query.filter_by(uploader_id=filters['uploader_id'])
        
        # Filter by tags
        if 'tags' in filters and filters['tags']:
            tag_ids = [t.id if hasattr(t, 'id') else t for t in filters['tags']]
            search_query = search_query.filter(
                KnowledgeAsset.tags.any(Tag.id.in_(tag_ids))
            )
        
        # Order by relevance and date
        search_query = search_query.order_by(
            KnowledgeAsset.published_at.desc(),
            KnowledgeAsset.view_count.desc()
        )
        
        # Paginate
        pagination = search_query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return pagination
    
    def advanced_search(self, criteria):
        """
        Advanced search with multiple criteria.
        
        Args:
            criteria: Dict with search parameters
                - query: Keyword search
                - tags: List of Tag objects
                - file_types: List of file types
                - date_from: Start date
                - date_to: End date
                - uploader_id: Specific uploader
                - min_views: Minimum view count
        
        Returns:
            list: Matching assets
        """
        search_query = KnowledgeAsset.query.filter_by(
            status=AssetStatus.PUBLISHED.value
        )
        
        if 'query' in criteria and criteria['query']:
            search_term = f"%{criteria['query']}%"
            search_query = search_query.filter(
                or_(
                    KnowledgeAsset.title.ilike(search_term),
                    KnowledgeAsset.description.ilike(search_term)
                )
            )
        
        if 'tags' in criteria and criteria['tags']:
            tag_ids = [t.id if hasattr(t, 'id') else t for t in criteria['tags']]
            search_query = search_query.filter(
                KnowledgeAsset.tags.any(Tag.id.in_(tag_ids))
            )
        
        if 'file_types' in criteria and criteria['file_types']:
            search_query = search_query.filter(
                KnowledgeAsset.file_type.in_(criteria['file_types'])
            )
        
        if 'date_from' in criteria:
            search_query = search_query.filter(
                KnowledgeAsset.published_at >= criteria['date_from']
            )
        
        if 'date_to' in criteria:
            search_query = search_query.filter(
                KnowledgeAsset.published_at <= criteria['date_to']
            )
        
        if 'uploader_id' in criteria:
            search_query = search_query.filter_by(
                uploader_id=criteria['uploader_id']
            )
        
        if 'min_views' in criteria:
            search_query = search_query.filter(
                KnowledgeAsset.view_count >= criteria['min_views']
            )
        
        return search_query.all()
    
    def get_related_assets(self, asset_id, limit=5):
        """
        Get related assets based on tags.
        
        Args:
            asset_id: ID of reference asset
            limit: Number of related assets
        
        Returns:
            list: Related assets
        """
        asset = KnowledgeAsset.query.get(asset_id)
        if not asset:
            return []
        
        # Get assets with same tags
        related = KnowledgeAsset.query.filter(
            KnowledgeAsset.id != asset_id,
            KnowledgeAsset.status == AssetStatus.PUBLISHED.value,
            KnowledgeAsset.tags.any(Tag.id.in_(
                [tag.id for tag in asset.tags]
            ))
        ).limit(limit).all()
        
        return related
    
    def get_trending_assets(self, limit=10):
        """
        Get trending assets by view count.
        
        Args:
            limit: Number of assets
        
        Returns:
            list: Trending assets
        """
        return KnowledgeAsset.query.filter_by(
            status=AssetStatus.PUBLISHED.value
        ).order_by(
            KnowledgeAsset.view_count.desc()
        ).limit(limit).all()
    
    def get_recent_assets(self, limit=10):
        """
        Get recently published assets.
        
        Args:
            limit: Number of assets
        
        Returns:
            list: Recent assets
        """
        return KnowledgeAsset.query.filter_by(
            status=AssetStatus.PUBLISHED.value
        ).order_by(
            KnowledgeAsset.published_at.desc()
        ).limit(limit).all()
