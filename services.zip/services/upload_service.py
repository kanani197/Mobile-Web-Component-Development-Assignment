"""Upload service for handling asset uploads."""
from flask import current_app
from flask_login import current_user
from extensions import db
from models import KnowledgeAsset, Tag, AssetStatus
from utils.file_handler import save_upload_file, extract_text_from_file, get_file_size
from services.recommendation_engine import RecommendationEngine
from services.audit_service import AuditService
from services.notification_service import NotificationService
import os

class UploadService:
    """Service for handling knowledge asset uploads."""
    
    def __init__(self):
        """Initialize upload service."""
        self.recommendation_engine = RecommendationEngine()
        self.audit_service = AuditService()
        self.notification_service = NotificationService()
    
    def upload_asset(self, file, title, description, expertise_areas=None):
        """
        Upload a knowledge asset.
        
        Args:
            file: FileStorage object
            title: Asset title
            description: Asset description
            expertise_areas: List of expertise area names
        
        Returns:
            tuple: (KnowledgeAsset object, error_message)
        """
        # Validate file
        if not file or file.filename == '':
            return None, 'No file selected'
        
        # Save file
        filename, filepath = save_upload_file(file)
        if not filename:
            return None, 'Invalid file type or file too large'
        
        # Extract file info
        file_type = file.filename.rsplit('.', 1)[1].lower()
        file_size = get_file_size(filepath)
        
        # Extract text content
        content = extract_text_from_file(filepath, file_type)
        
        # Create asset
        asset = KnowledgeAsset(
            title=title,
            description=description,
            file_path=filename,
            file_type=file_type,
            file_size=file_size,
            content=content,
            uploader_id=current_user.id,
            status=AssetStatus.PENDING_VALIDATION.value
        )
        
        # Suggest tags
        suggested_tags = self.recommendation_engine.suggest_tags(
            title, description, content
        )
        for tag in suggested_tags:
            asset.tags.append(tag)
        
        # Add to database
        db.session.add(asset)
        db.session.flush()  # Get asset ID
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_uploaded',
            'asset',
            asset.id,
            {'title': title, 'file_type': file_type}
        )
        
        # Commit
        db.session.commit()
        
        # Notify champions
        self.notification_service.notify_champions_new_asset(asset)
        
        return asset, None
    
    def get_asset_by_id(self, asset_id):
        """Get asset by ID."""
        return KnowledgeAsset.query.get(asset_id)
    
    def delete_asset(self, asset_id):
        """Delete an asset."""
        asset = self.get_asset_by_id(asset_id)
        if not asset:
            return False, 'Asset not found'
        
        # Check permission
        if asset.uploader_id != current_user.id and not current_user.is_admin():
            return False, 'Permission denied'
        
        # Delete file
        try:
            filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], asset.file_path)
            if os.path.exists(filepath):
                os.remove(filepath)
        except Exception as e:
            current_app.logger.error(f"Error deleting file: {e}")
        
        # Delete from database
        db.session.delete(asset)
        db.session.commit()
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_deleted',
            'asset',
            asset_id,
            {'title': asset.title}
        )
        
        return True, 'Asset deleted successfully'
