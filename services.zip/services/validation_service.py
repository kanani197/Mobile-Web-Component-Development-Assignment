"""Validation service for asset validation workflow."""
from datetime import datetime
from flask import current_app
from flask_login import current_user
from extensions import db
from models import KnowledgeAsset, User, AssetStatus
from services.audit_service import AuditService
from services.notification_service import NotificationService

class ValidationService:
    """Service for handling asset validation."""
    
    def __init__(self):
        """Initialize validation service."""
        self.audit_service = AuditService()
        self.notification_service = NotificationService()
    
    def get_pending_assets(self):
        """Get assets pending validation."""
        return KnowledgeAsset.query.filter_by(
            status=AssetStatus.PENDING_VALIDATION.value
        ).all()
    
    def get_pending_governance_assets(self):
        """Get assets pending governance review."""
        return KnowledgeAsset.query.filter_by(
            status=AssetStatus.PENDING_GOVERNANCE.value
        ).all()
    
    def approve_asset(self, asset_id, comments=None, send_to_governance=False):
        """
        Approve an asset for publication.
        
        Args:
            asset_id: ID of asset to approve
            comments: Validation comments
            send_to_governance: Whether to send to governance review
        
        Returns:
            tuple: (success, message)
        """
        asset = KnowledgeAsset.query.get(asset_id)
        if not asset:
            return False, 'Asset not found'
        
        # Check permission
        if not current_user.is_champion_or_admin():
            return False, 'Permission denied'
        
        # Check status
        if asset.status != AssetStatus.PENDING_VALIDATION.value:
            return False, 'Asset is not pending validation'
        
        # Update asset
        asset.validator_id = current_user.id
        asset.validation_comments = comments
        
        if send_to_governance:
            asset.status = AssetStatus.PENDING_GOVERNANCE.value
            message = 'Asset sent to governance review'
        else:
            asset.status = AssetStatus.PUBLISHED.value
            asset.published_at = datetime.utcnow()
            message = 'Asset approved and published'
        
        db.session.commit()
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_approved',
            'asset',
            asset_id,
            {'new_status': asset.status, 'comments': comments}
        )
        
        # Send notifications
        self.notification_service.notify_uploader_approved(asset)
        if send_to_governance:
            self.notification_service.notify_governance_new_review(asset)
        
        return True, message
    
    def reject_asset(self, asset_id, comments=None):
        """
        Reject an asset.
        
        Args:
            asset_id: ID of asset to reject
            comments: Rejection comments
        
        Returns:
            tuple: (success, message)
        """
        asset = KnowledgeAsset.query.get(asset_id)
        if not asset:
            return False, 'Asset not found'
        
        # Check permission
        if not current_user.is_champion_or_admin():
            return False, 'Permission denied'
        
        # Check status
        if asset.status not in [AssetStatus.PENDING_VALIDATION.value, 
                               AssetStatus.PENDING_GOVERNANCE.value]:
            return False, 'Asset cannot be rejected in current status'
        
        # Update asset
        asset.status = AssetStatus.REJECTED.value
        asset.validation_comments = comments or asset.validation_comments
        
        db.session.commit()
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_rejected',
            'asset',
            asset_id,
            {'comments': comments}
        )
        
        # Send notification
        self.notification_service.notify_uploader_rejected(asset)
        
        return True, 'Asset rejected'
    
    def governance_approve(self, asset_id, comments=None):
        """
        Governance approval of asset.
        
        Args:
            asset_id: ID of asset
            comments: Governance comments
        
        Returns:
            tuple: (success, message)
        """
        asset = KnowledgeAsset.query.get(asset_id)
        if not asset:
            return False, 'Asset not found'
        
        # Check permission
        if not current_user.is_governance():
            return False, 'Permission denied'
        
        # Check status
        if asset.status != AssetStatus.PENDING_GOVERNANCE.value:
            return False, 'Asset is not pending governance review'
        
        # Update asset
        asset.governance_approver_id = current_user.id
        asset.governance_comments = comments
        asset.status = AssetStatus.PUBLISHED.value
        asset.published_at = datetime.utcnow()
        
        db.session.commit()
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_governance_approved',
            'asset',
            asset_id,
            {'comments': comments}
        )
        
        # Send notifications
        self.notification_service.notify_uploader_approved(asset)
        
        return True, 'Asset approved by governance and published'
    
    def governance_reject(self, asset_id, comments=None):
        """
        Governance rejection of asset.
        
        Args:
            asset_id: ID of asset
            comments: Rejection comments
        
        Returns:
            tuple: (success, message)
        """
        asset = KnowledgeAsset.query.get(asset_id)
        if not asset:
            return False, 'Asset not found'
        
        # Check permission
        if not current_user.is_governance():
            return False, 'Permission denied'
        
        # Check status
        if asset.status != AssetStatus.PENDING_GOVERNANCE.value:
            return False, 'Asset is not pending governance review'
        
        # Update asset
        asset.governance_comments = comments
        asset.status = AssetStatus.REJECTED.value
        
        db.session.commit()
        
        # Log audit
        self.audit_service.log_action(
            current_user.id,
            'asset_governance_rejected',
            'asset',
            asset_id,
            {'comments': comments}
        )
        
        # Send notification
        self.notification_service.notify_uploader_rejected(asset)
        
        return True, 'Asset rejected by governance'
