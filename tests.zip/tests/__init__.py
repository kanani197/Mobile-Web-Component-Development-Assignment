"""Tests init file."""
