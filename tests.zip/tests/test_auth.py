"""Tests for authentication routes."""
import pytest

def test_register_get(client):
    """Test registration page loads."""
    response = client.get('/auth/register')
    assert response.status_code == 200
    assert b'Register' in response.data

def test_register_post_valid(client):
    """Test valid registration."""
    response = client.post('/auth/register', data={
        'username': 'newuser',
        'email': 'new@example.com',
        'password': 'password123',
        'password_confirm': 'password123',
        'first_name': 'New',
        'last_name': 'User',
        'role': 'consultant'
    })
    assert response.status_code == 302  # Redirect to login

def test_register_post_invalid_password(client):
    """Test registration with mismatched passwords."""
    response = client.post('/auth/register', data={
        'username': 'newuser',
        'email': 'new@example.com',
        'password': 'password123',
        'password_confirm': 'different',
        'role': 'consultant'
    })
    assert response.status_code == 200
    assert b'Passwords do not match' in response.data

def test_login_get(client):
    """Test login page loads."""
    response = client.get('/auth/login')
    assert response.status_code == 200
    assert b'Login' in response.data

def test_login_post_valid(client, test_user):
    """Test valid login."""
    response = client.post('/auth/login', data={
        'username': 'testuser',
        'password': 'password123'
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b'Dashboard' in response.data or b'DKN System' in response.data

def test_login_post_invalid(client):
    """Test login with invalid credentials."""
    response = client.post('/auth/login', data={
        'username': 'nonexistent',
        'password': 'wrongpassword'
    })
    assert response.status_code == 200
    assert b'Invalid username or password' in response.data

def test_logout(client, test_user):
    """Test logout."""
    client.post('/auth/login', data={
        'username': 'testuser',
        'password': 'password123'
    })
    response = client.get('/auth/logout', follow_redirects=True)
    assert response.status_code == 200
    assert b'logged out' in response.data.lower()
