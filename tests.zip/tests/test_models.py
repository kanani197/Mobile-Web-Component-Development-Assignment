"""Tests for models."""
import pytest
from models import User, KnowledgeAsset, AssetStatus

def test_user_creation(app):
    """Test user model creation."""
    from extensions import db
    user = User(
        username='testuser',
        email='test@example.com'
    )
    user.set_password('password123')
    assert user.check_password('password123')
    assert not user.check_password('wrongpassword')

def test_user_roles(app):
    """Test user roles."""
    from extensions import db
    user = User(
        username='testuser',
        email='test@example.com',
        role='consultant'
    )
    assert user.has_role('consultant')
    assert not user.has_role('admin')

def test_user_full_name(app):
    """Test user full name."""
    user = User(
        username='testuser',
        email='test@example.com',
        first_name='John',
        last_name='Doe'
    )
    assert user.full_name == 'John Doe'

def test_knowledge_asset_creation(app, test_user):
    """Test knowledge asset creation."""
    from extensions import db
    with app.app_context():
        asset = KnowledgeAsset(
            title='Test Asset',
            description='Test Description',
            uploader_id=test_user.id
        )
        assert asset.status == AssetStatus.DRAFT.value
        assert not asset.is_published()

def test_asset_status_workflow(app, test_user):
    """Test asset status transitions."""
    from extensions import db
    with app.app_context():
        asset = KnowledgeAsset(
            title='Test Asset',
            uploader_id=test_user.id,
            status=AssetStatus.PENDING_VALIDATION.value
        )
        assert asset.is_pending_validation()
        
        asset.status = AssetStatus.PUBLISHED.value
        assert asset.is_published()
