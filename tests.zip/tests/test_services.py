"""Tests for services."""
import pytest
from models import KnowledgeAsset, Tag, User
from services import RecommendationEngine, SearchService
from extensions import db

def test_recommendation_engine_init(app):
    """Test recommendation engine initialization."""
    engine = RecommendationEngine()
    assert engine is not None

def test_search_service_init(app):
    """Test search service initialization."""
    service = SearchService()
    assert service is not None

def test_search_empty_results(app, client):
    """Test search with no results."""
    service = SearchService()
    with app.app_context():
        results = service.search('nonexistent')
        assert results.total == 0

def test_audit_logging(app, test_user):
    """Test audit service logging."""
    from services import AuditService
    from models import AuditLog
    with app.app_context():
        AuditService.log_action(
            test_user.id,
            'test_action',
            'test_resource',
            123,
            {'test': 'data'}
        )
        log = AuditLog.query.filter_by(user_id=test_user.id).first()
        assert log is not None
        assert log.action == 'test_action'
