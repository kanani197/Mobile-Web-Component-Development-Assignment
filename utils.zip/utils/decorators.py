"""Utility decorators for authorization."""
from functools import wraps
from flask import redirect, url_for, flash, abort
from flask_login import current_user

def role_required(*roles):
    """Decorator to require specific user roles."""
    def decorator(func):
        @wraps(func)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('auth.login'))
            
            if current_user.role not in roles:
                flash('You do not have permission to access this page.', 'danger')
                abort(403)
            
            return func(*args, **kwargs)
        return decorated_function
    return decorator

def champion_or_admin_required(func):
    """Decorator to require champion or admin role."""
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        
        if not current_user.is_champion_or_admin():
            flash('You do not have permission to access this page.', 'danger')
            abort(403)
        
        return func(*args, **kwargs)
    return decorated_function

def governance_required(func):
    """Decorator to require governance role."""
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        
        if not current_user.is_governance():
            flash('You do not have permission to access this page.', 'danger')
            abort(403)
        
        return func(*args, **kwargs)
    return decorated_function

def admin_required(func):
    """Decorator to require admin role."""
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        
        if not current_user.is_admin():
            flash('You do not have permission to access this page.', 'danger')
            abort(403)
        
        return func(*args, **kwargs)
    return decorated_function
