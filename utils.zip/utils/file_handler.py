"""File handling utilities."""
import os
import secrets
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import current_app
import PyPDF2

# Optional imports that may not be available
try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'xlsx', 'txt', 'doc', 'xls', 'pptx'}

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_unique_filename(filename):
    """Generate unique filename with timestamp."""
    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    name, ext = os.path.splitext(secure_filename(filename))
    return f"{name}_{timestamp}_{secrets.token_hex(4)}{ext}"

def save_upload_file(file):
    """
    Save uploaded file and return path.
    
    Args:
        file: FileStorage object from Flask
    
    Returns:
        tuple: (relative_path, absolute_path) or (None, None) if invalid
    """
    if not file or not allowed_file(file.filename):
        return None, None
    
    filename = generate_unique_filename(file.filename)
    upload_folder = current_app.config['UPLOAD_FOLDER']
    
    # Create uploads folder if doesn't exist
    os.makedirs(upload_folder, exist_ok=True)
    
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)
    
    return filename, filepath

def extract_text_from_pdf(filepath):
    """Extract text from PDF file."""
    try:
        text = []
        with open(filepath, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text.append(page.extract_text())
        return ' '.join(text)
    except Exception as e:
        current_app.logger.error(f"Error extracting PDF text: {e}")
        return ""

def extract_text_from_docx(filepath):
    """Extract text from DOCX file."""
    if not HAS_DOCX:
        current_app.logger.warning("python-docx not installed, returning empty text")
        return ""
    
    try:
        doc = Document(filepath)
        text = []
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                text.append(paragraph.text)
        return ' '.join(text)
    except Exception as e:
        current_app.logger.error(f"Error extracting DOCX text: {e}")
        return ""

def extract_text_from_file(filepath, file_type):
    """
    Extract text content from file.
    
    Args:
        filepath: Path to the file
        file_type: File extension (pdf, docx, txt, etc.)
    
    Returns:
        str: Extracted text content
    """
    file_type = file_type.lower() if file_type else ''
    
    try:
        if file_type == 'pdf':
            return extract_text_from_pdf(filepath)
        elif file_type in ['docx', 'doc']:
            return extract_text_from_docx(filepath)
        elif file_type == 'txt':
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        else:
            # Try text extraction as fallback
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
    except Exception as e:
        current_app.logger.error(f"Error extracting text: {e}")
        return ""

def get_file_size(filepath):
    """Get file size in bytes."""
    try:
        return os.path.getsize(filepath)
    except OSError:
        return 0
